package com.example.myappmasterd

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.util.Log
import android.widget.Button
import androidx.appcompat.widget.AppCompatButton
class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)


        val btnStart =findViewById<Button>(R.id.btnStart)
        val btnWelcome = findViewById<Button>(R.id.btnWelcome)
        val btnThird = findViewById<Button>(R.id.btnThird)

        // Acción botón 1
        btnStart.setOnClickListener {
            Log.i("manu-dev", "Se presionó el botón ENVIAR")
        }

        // Acción botón 2
        btnWelcome.setOnClickListener {
            Log.i("manu-dev", "Se presionó el botón BIENVENIDO")
        }

        // Acción botón 3
        btnThird.setOnClickListener {
            Log.i("manu-dev", "Se presionó el botón TERCERO")
        }
    }
}
