package com.example.taller_20

class taller_20 {
}

//fun main (){    B) PAR
//    val numero = 8
//
//    if (numero % 2 == 0){
//        println("Par")
//    }else{
//        println("Inpar")
//    }
//}

//fun main (){        D) ADULTO MAYOR                 REVISAR
//
//    val edad = 65
//    if (edad <12){
//        println("Niño")
//    }else if (edad in :<= 12 <=17){
//        println("Adolescente")
//    }else if (edad in 18<= <=59){
//        println("Adulto")
//    }else{
//        println("Adulto mayor")
//    }
//}

//fun main (){  //B) BUENO
//
//    val nota = 72
//    if (nota >= 90){
//        println("Excelente")
//    }else if (nota >= 70){
//        println("Bueno")
//    }else if (nota >= 50){
//        println("Regular")
//    }else{
//        println("Reprobado")
//    }
//}


//fun main (){  //A) ISOSCELES
//    val a = 5
//    val b = 5
//    val c = 8
//    if ( a == b && b == c){
//        println("equilatero")
//    }else if (a == b || a == c || b == c){
//        println("isosceles")
//    }else{
//        println("Escaleno")
//    }
//}

//fun main (){ A) PAR PRIMERA IMPAR SEGUNDA
//
//    val numero = 7
//    if (numero % 2 == 0){
//        println("Par")
//    }else{
//        println("Impar")
//    }
//}


//fun main (){        //ORDENA LAS INSTRUCCIONES
//    val numero = 0
//    if (numero > 0){
//        println("Positivo")
//    }else if (numero == 0){
//        println("Cero")
//    }else{
//        println("Negativo")
//    }
//}

//fun saludarPersona(nombre: String){ //C) HOLA ANA HOLA LUIS
//    println("Hola $nombre")
//}
//
//fun main (){
//    saludarPersona(nombre = "Ana")
//    saludarPersona(nombre = "Luis")
//}

//fun mostrarDoble(numero: Int){ // B) El doble de 4 es 8 El doble de 10 es 20
//    println("el doble de $numero es ${numero * 2}")
//}
//fun main (){
//    mostrarDoble(numero = 4)
//    mostrarDoble(numero = 10)
//}

//fun evaluarNota (nota: Int){ B) RESPUESTA B
//    if (nota >= 60){
//        println("El estudiante aprueba con $nota")
//    }else{
//        println("El estudiante reprueba con $nota")
//    }
//}
//
//fun main(){
//    evaluarNota (nota = 75)
//}

